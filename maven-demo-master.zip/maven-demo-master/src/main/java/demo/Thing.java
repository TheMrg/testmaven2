package demo;

public class Thing {

}
